<?php 


phpinfo();


 ?>